// Image configuration for easy management
export const productImages = {
  featured: {
    silkDreams: "/images/products/silk-dreams-bra-set.jpg",
    laceElegance: "/images/products/lace-elegance-bra.jpg",
    comfortPlus: "/images/products/comfort-wireless-bra.jpg",
    romanticRose: "/images/products/romantic-rose-set.jpg",
    classicBlack: "/images/products/classic-black-lace.jpg",
    champagneDreams: "/images/products/champagne-satin-set.jpg",
    midnightVelvet: "/images/products/midnight-velvet-bra.jpg",
    pearlWhite: "/images/products/pearl-white-luxury.jpg",
  },
  categories: {
    bras: [
      "/images/categories/lace-pushup-rose.jpg",
      "/images/categories/silk-comfort-ivory.jpg",
      "/images/categories/wireless-tshirt-black.jpg",
      "/images/categories/balconette-champagne.jpg",
    ],
    panties: [
      "/images/categories/lace-bikini-rose.jpg",
      "/images/categories/silk-brief-ivory.jpg",
      "/images/categories/seamless-thong-black.jpg",
      "/images/categories/boyshort-champagne.jpg",
    ],
    sets: [
      "/images/categories/luxury-bridal-white.jpg",
      "/images/categories/romantic-lace-rose.jpg",
      "/images/categories/classic-satin-black.jpg",
      "/images/categories/vintage-inspired-gold.jpg",
    ],
    sleepwear: [
      "/images/categories/silk-camisole-champagne.jpg",
      "/images/categories/satin-pajama-rose.jpg",
      "/images/categories/lace-robe-ivory.jpg",
      "/images/categories/elegant-nightgown-black.jpg",
    ],
  },
  hero: {
    model1: "/images/hero/elegant-model-rose-gold.jpg",
    model2: "/images/hero/sophisticated-model-champagne.jpg",
  },
}
