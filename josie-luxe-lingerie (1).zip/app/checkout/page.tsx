"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Shield, Truck, RotateCcw, CreditCard, Building2, Phone, Mail } from "lucide-react"
import Image from "next/image"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default function CheckoutPage() {
  const [paymentMethod, setPaymentMethod] = useState("bank-transfer")

  const cartItems = [
    {
      id: 1,
      name: "Silk Dreams Bra Set",
      price: 299.99,
      quantity: 1,
      size: "34B",
      color: "Rose Gold",
      image: "/placeholder.svg?height=100&width=80&text=Silk+Bra+Set",
    },
    {
      id: 2,
      name: "Lace Elegance Panties",
      price: 89.99,
      quantity: 2,
      size: "M",
      color: "Ivory",
      image: "/placeholder.svg?height=100&width=80&text=Lace+Panties",
    },
  ]

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const shipping = subtotal > 129 ? 0 : 15
  const tax = subtotal * 0.06 // 6% SST
  const total = subtotal + shipping + tax

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-stone-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-stone-800 mb-2">Secure Checkout</h1>
            <p className="text-stone-600">Complete your luxury lingerie purchase</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column - Forms */}
            <div className="space-y-6">
              {/* Shipping Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Truck className="w-5 h-5 text-rose-500" />
                    Shipping Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input id="firstName" placeholder="Enter first name" />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input id="lastName" placeholder="Enter last name" />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="email">Email Address</Label>
                    <Input id="email" type="email" placeholder="your@email.com" />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input id="phone" placeholder="+60 12-345 6789" />
                  </div>
                  <div>
                    <Label htmlFor="address">Street Address</Label>
                    <Input id="address" placeholder="123 Jalan Example" />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="city">City</Label>
                      <Input id="city" placeholder="Kuala Lumpur" />
                    </div>
                    <div>
                      <Label htmlFor="state">State</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select state" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="selangor">Selangor</SelectItem>
                          <SelectItem value="kl">Kuala Lumpur</SelectItem>
                          <SelectItem value="johor">Johor</SelectItem>
                          <SelectItem value="penang">Penang</SelectItem>
                          <SelectItem value="sabah">Sabah</SelectItem>
                          <SelectItem value="sarawak">Sarawak</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="postcode">Postcode</Label>
                      <Input id="postcode" placeholder="50000" />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="notes">Special Instructions (Optional)</Label>
                    <Textarea id="notes" placeholder="Any special delivery instructions..." />
                  </div>
                </CardContent>
              </Card>

              {/* Payment Method */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-rose-500" />
                    Payment Method
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Bank Transfer Option */}
                  <div className="border rounded-lg p-4 bg-gradient-to-r from-rose-50 to-amber-50">
                    <div className="flex items-center gap-3 mb-4">
                      <input
                        type="radio"
                        id="bank-transfer"
                        name="payment"
                        value="bank-transfer"
                        checked={paymentMethod === "bank-transfer"}
                        onChange={(e) => setPaymentMethod(e.target.value)}
                        className="text-rose-500"
                      />
                      <label htmlFor="bank-transfer" className="flex items-center gap-2 font-semibold">
                        <Building2 className="w-5 h-5 text-rose-500" />
                        Bank Transfer (Recommended)
                      </label>
                      <Badge className="bg-green-500">Secure</Badge>
                    </div>

                    {paymentMethod === "bank-transfer" && (
                      <div className="bg-white rounded-lg p-4 border-2 border-rose-200">
                        <h4 className="font-semibold text-stone-800 mb-3">Bank Transfer Details:</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-stone-600">Bank:</span>
                            <span className="font-semibold">RHB BANK</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-stone-600">Account Number:</span>
                            <span className="font-mono font-bold text-lg">21206800093181</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-stone-600">Account Name:</span>
                            <span className="font-semibold">JOSIE LUXE SDN BHD</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-stone-600">Reference:</span>
                            <span className="font-semibold">Your Order Number</span>
                          </div>
                        </div>
                        <div className="mt-4 p-3 bg-amber-50 rounded-lg border border-amber-200">
                          <p className="text-sm text-amber-800">
                            <strong>Important:</strong> Please include your order number as reference when making the
                            transfer. Upload your payment receipt after placing the order for faster processing.
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Online Banking Option */}
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        id="online-banking"
                        name="payment"
                        value="online-banking"
                        checked={paymentMethod === "online-banking"}
                        onChange={(e) => setPaymentMethod(e.target.value)}
                      />
                      <label htmlFor="online-banking" className="flex items-center gap-2 font-semibold">
                        <CreditCard className="w-5 h-5 text-blue-500" />
                        Online Banking
                      </label>
                      <Badge variant="outline">Coming Soon</Badge>
                    </div>
                  </div>

                  {/* Cash on Delivery */}
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        id="cod"
                        name="payment"
                        value="cod"
                        checked={paymentMethod === "cod"}
                        onChange={(e) => setPaymentMethod(e.target.value)}
                      />
                      <label htmlFor="cod" className="flex items-center gap-2 font-semibold">
                        <Truck className="w-5 h-5 text-green-500" />
                        Cash on Delivery
                      </label>
                      <Badge className="bg-blue-500">+RM10 Fee</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Order Summary */}
            <div className="space-y-6">
              {/* Order Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex gap-4">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        width={80}
                        height={100}
                        className="rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold text-stone-800">{item.name}</h4>
                        <p className="text-sm text-stone-600">
                          Size: {item.size} | Color: {item.color}
                        </p>
                        <p className="text-sm text-stone-600">Qty: {item.quantity}</p>
                        <p className="font-semibold text-rose-600">RM{(item.price * item.quantity).toFixed(2)}</p>
                      </div>
                    </div>
                  ))}

                  <Separator />

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>RM{subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Shipping:</span>
                      <span>{shipping === 0 ? "FREE" : `RM${shipping.toFixed(2)}`}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Tax (SST 6%):</span>
                      <span>RM{tax.toFixed(2)}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total:</span>
                      <span className="text-rose-600">RM{total.toFixed(2)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Trust Badges */}
              <Card>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-1 gap-4">
                    <div className="flex items-center gap-3 text-sm">
                      <Shield className="w-5 h-5 text-green-500" />
                      <span>Secure SSL Encryption</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <Truck className="w-5 h-5 text-blue-500" />
                      <span>Free Shipping Above RM129</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <RotateCcw className="w-5 h-5 text-purple-500" />
                      <span>30-Day Return Policy</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Need Help?</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-3 text-sm">
                    <Phone className="w-4 h-4 text-rose-500" />
                    <span>+60 12-345 6789</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <Mail className="w-4 h-4 text-rose-500" />
                    <span>support@josieluxe.com</span>
                  </div>
                  <p className="text-xs text-stone-600">Customer service available Mon-Fri, 9AM-6PM</p>
                </CardContent>
              </Card>

              {/* Place Order Button */}
              <Button
                size="lg"
                className="w-full bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white font-semibold py-4"
              >
                Place Order - RM{total.toFixed(2)}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
