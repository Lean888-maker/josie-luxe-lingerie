import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-stone-800 mb-8 font-playfair">Terms of Service</h1>

          <div className="prose prose-stone max-w-none space-y-8">
            <section>
              <h2 className="text-2xl font-semibold text-stone-800 mb-4">Acceptance of Terms</h2>
              <p className="text-stone-600 leading-relaxed">
                By accessing and using the Josie Luxe website, you accept and agree to be bound by the terms and
                provision of this agreement.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-stone-800 mb-4">Product Information</h2>
              <p className="text-stone-600 leading-relaxed">
                We strive to provide accurate product descriptions and images. However, we do not warrant that product
                descriptions or other content is accurate, complete, reliable, current, or error-free.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-stone-800 mb-4">Orders and Payment</h2>
              <ul className="list-disc pl-6 text-stone-600 space-y-2">
                <li>All orders are subject to acceptance and availability</li>
                <li>Prices are subject to change without notice</li>
                <li>Payment must be received before order processing</li>
                <li>We reserve the right to refuse or cancel any order</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-stone-800 mb-4">Returns and Exchanges</h2>
              <p className="text-stone-600 leading-relaxed">
                Items may be returned within 30 days of purchase in original condition with tags attached. Intimate
                apparel must be unworn and in hygienic condition for health and safety reasons.
              </p>
            </section>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
