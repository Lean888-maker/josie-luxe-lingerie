import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function SizeGuidePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold text-stone-800 mb-8 font-playfair text-center">Size Guide</h1>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Bra Size Guide */}
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-stone-800">Bra Size Guide</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2">Size</th>
                        <th className="text-left py-2">Band (inches)</th>
                        <th className="text-left py-2">Cup</th>
                      </tr>
                    </thead>
                    <tbody className="text-stone-600">
                      <tr className="border-b">
                        <td className="py-2">32A</td>
                        <td className="py-2">28-30</td>
                        <td className="py-2">A</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">32B</td>
                        <td className="py-2">28-30</td>
                        <td className="py-2">B</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">34B</td>
                        <td className="py-2">30-32</td>
                        <td className="py-2">B</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">34C</td>
                        <td className="py-2">30-32</td>
                        <td className="py-2">C</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">36C</td>
                        <td className="py-2">32-34</td>
                        <td className="py-2">C</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* Panties Size Guide */}
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-stone-800">Panties Size Guide</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2">Size</th>
                        <th className="text-left py-2">Waist (inches)</th>
                        <th className="text-left py-2">Hip (inches)</th>
                      </tr>
                    </thead>
                    <tbody className="text-stone-600">
                      <tr className="border-b">
                        <td className="py-2">XS</td>
                        <td className="py-2">24-26</td>
                        <td className="py-2">34-36</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">S</td>
                        <td className="py-2">26-28</td>
                        <td className="py-2">36-38</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">M</td>
                        <td className="py-2">28-30</td>
                        <td className="py-2">38-40</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">L</td>
                        <td className="py-2">30-32</td>
                        <td className="py-2">40-42</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2">XL</td>
                        <td className="py-2">32-34</td>
                        <td className="py-2">42-44</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-12 bg-rose-50 rounded-lg p-8">
            <h2 className="text-2xl font-semibold text-stone-800 mb-4">How to Measure</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold text-stone-800 mb-2">For Bras:</h3>
                <ul className="text-stone-600 space-y-1">
                  <li>• Measure around your ribcage, just under your bust</li>
                  <li>• Measure around the fullest part of your bust</li>
                  <li>• Subtract band measurement from bust measurement</li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-stone-800 mb-2">For Panties:</h3>
                <ul className="text-stone-600 space-y-1">
                  <li>• Measure around your natural waistline</li>
                  <li>• Measure around the fullest part of your hips</li>
                  <li>• Use the larger measurement for sizing</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
