import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-stone-800 mb-8 font-playfair">Privacy Policy</h1>

          <div className="prose prose-stone max-w-none space-y-8">
            <section>
              <h2 className="text-2xl font-semibold text-stone-800 mb-4">Information We Collect</h2>
              <p className="text-stone-600 leading-relaxed">
                At Josie Luxe, we collect information you provide directly to us, such as when you create an account,
                make a purchase, subscribe to our newsletter, or contact us for support. This may include your name,
                email address, phone number, shipping address, and payment information.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-stone-800 mb-4">How We Use Your Information</h2>
              <ul className="list-disc pl-6 text-stone-600 space-y-2">
                <li>Process and fulfill your orders</li>
                <li>Communicate with you about your purchases</li>
                <li>Send you promotional materials (with your consent)</li>
                <li>Improve our products and services</li>
                <li>Comply with legal obligations</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-stone-800 mb-4">Data Protection</h2>
              <p className="text-stone-600 leading-relaxed">
                We implement appropriate security measures to protect your personal information against unauthorized
                access, alteration, disclosure, or destruction. All payment information is processed through secure,
                encrypted connections.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-stone-800 mb-4">Contact Us</h2>
              <p className="text-stone-600 leading-relaxed">
                If you have any questions about this Privacy Policy, please contact us at:
                <br />
                Email: privacy@josieluxe.com
                <br />
                Phone: +60 12-345 6789
              </p>
            </section>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
