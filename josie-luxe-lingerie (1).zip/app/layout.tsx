import type React from "react"
import type { Metadata } from "next"
import { Inter, Playfair_Display } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })
const playfair = Playfair_Display({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
  variable: "--font-playfair",
  display: "swap",
})

export const metadata: Metadata = {
  title: "Josie Luxe - Premium Lingerie Collection",
  description:
    "Discover luxury intimate wear designed for the modern woman. Premium quality bras, panties, sets and sleepwear with elegant designs and superior comfort.",
  keywords: "lingerie, bras, panties, luxury underwear, intimate wear, Malaysia, premium quality",
  authors: [{ name: "Josie Luxe" }],
  openGraph: {
    title: "Josie Luxe - Premium Lingerie Collection",
    description: "Luxury intimate wear for the modern woman",
    url: "https://josieluxe.vercel.app",
    siteName: "Josie Luxe",
    images: [
      {
        url: "/placeholder.svg?height=630&width=1200&text=Josie+Luxe+Premium+Lingerie",
        width: 1200,
        height: 630,
      },
    ],
    locale: "en_MY",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Josie Luxe - Premium Lingerie Collection",
    description: "Luxury intimate wear for the modern woman",
    images: ["/placeholder.svg?height=630&width=1200&text=Josie+Luxe+Premium+Lingerie"],
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} ${playfair.variable}`}>{children}</body>
    </html>
  )
}
