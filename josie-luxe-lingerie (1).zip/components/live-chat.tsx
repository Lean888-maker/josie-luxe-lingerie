"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { MessageCircle, X, Send } from "lucide-react"

export function LiveChat() {
  const [isOpen, setIsOpen] = useState(false)
  const [message, setMessage] = useState("")

  return (
    <>
      {/* Chat Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className="w-14 h-14 rounded-full bg-rose-500 hover:bg-rose-600 shadow-lg"
          size="icon"
        >
          {isOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
        </Button>
      </div>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50 w-80">
          <Card className="shadow-2xl">
            <CardHeader className="bg-rose-500 text-white rounded-t-lg">
              <CardTitle className="text-lg">Chat with Josie Luxe</CardTitle>
              <p className="text-sm text-rose-100">We're here to help! 💬</p>
            </CardHeader>
            <CardContent className="p-4">
              <div className="h-64 bg-gray-50 rounded-lg p-4 mb-4 overflow-y-auto">
                <div className="bg-white rounded-lg p-3 mb-3 shadow-sm">
                  <p className="text-sm text-stone-600">Hi! Welcome to Josie Luxe. How can we help you today?</p>
                  <span className="text-xs text-stone-400">Customer Service</span>
                </div>
              </div>

              <div className="flex gap-2">
                <Input
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-1"
                />
                <Button size="icon" className="bg-rose-500 hover:bg-rose-600">
                  <Send className="w-4 h-4" />
                </Button>
              </div>

              <div className="mt-3 text-center">
                <p className="text-xs text-stone-500">Available Mon-Fri 9AM-6PM</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  )
}
