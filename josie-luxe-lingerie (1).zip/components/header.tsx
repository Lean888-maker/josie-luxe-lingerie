"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Heart, Menu, Search, ShoppingBag, Globe } from "lucide-react"
import Link from "next/link"

export function Header() {
  const [cartCount] = useState(3)

  return (
    <>
      <div className="bg-gradient-to-r from-rose-500 via-rose-600 to-amber-500 text-white text-center py-2 text-sm font-medium">
        <div className="container mx-auto px-4">
          <span className="font-bold">FREE SHIPPING</span> ABOVE RM129 |
          <span className="font-bold ml-2">SEASONAL SALE</span> UP TO 60% OFF |
          <span className="font-bold ml-2">LUXURY COLLECTION</span> NOW AVAILABLE!
        </div>
      </div>

      <header className="sticky top-0 z-50 bg-white border-b border-stone-200 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/sale" className="text-red-500 hover:text-red-600 transition-colors font-bold">
                SALE
              </Link>
              <Link href="/products" className="text-stone-700 hover:text-rose-500 transition-colors font-medium">
                SHOP
              </Link>
              <Link href="/size-guide" className="text-stone-700 hover:text-rose-500 transition-colors font-medium">
                SIZE GUIDE
              </Link>
              <Link href="/about" className="text-stone-700 hover:text-rose-500 transition-colors font-medium">
                ABOUT
              </Link>
              <Link href="/contact" className="text-stone-700 hover:text-rose-500 transition-colors font-medium">
                CONTACT
              </Link>
            </nav>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80">
                <div className="flex flex-col gap-4 mt-8">
                  <Link href="/sale" className="text-lg font-medium text-red-500">
                    SALE
                  </Link>
                  <Link href="/products" className="text-lg font-medium">
                    SHOP
                  </Link>
                  <Link href="/size-guide" className="text-lg font-medium">
                    SIZE GUIDE
                  </Link>
                  <Link href="/about" className="text-lg font-medium">
                    ABOUT
                  </Link>
                  <Link href="/contact" className="text-lg font-medium">
                    CONTACT
                  </Link>
                </div>
              </SheetContent>
            </Sheet>

            <Link href="/" className="flex items-center">
              <span
                className="text-2xl font-bold tracking-wider font-playfair"
                style={{
                  background: "linear-gradient(135deg, #e11d48 0%, #f59e0b 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                  letterSpacing: "0.1em",
                  textShadow: "0 2px 4px rgba(0,0,0,0.1)",
                }}
              >
                JOSIE <span style={{ fontStyle: "italic", fontWeight: "300" }}>Luxe</span>
              </span>
            </Link>

            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm" className="hidden md:flex text-stone-700 hover:text-rose-500">
                Login
              </Button>
              <Button variant="ghost" size="icon" className="text-stone-700 hover:text-rose-500">
                <Search className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-stone-700 hover:text-rose-500">
                <Globe className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-stone-700 hover:text-rose-500">
                <Heart className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="relative text-stone-700 hover:text-rose-500">
                <ShoppingBag className="w-5 h-5" />
                {cartCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center p-0 bg-rose-500">
                    {cartCount}
                  </Badge>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>
    </>
  )
}
