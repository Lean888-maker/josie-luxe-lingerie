import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"
import Image from "next/image"

export function Testimonials() {
  const testimonials = [
    {
      name: "Sarah L.",
      location: "Kuala Lumpur",
      rating: 5,
      comment: "The quality is amazing! The silk bra set is so comfortable and elegant. Will definitely order again!",
      image: "/placeholder.svg?height=60&width=60&text=S",
    },
    {
      name: "Michelle T.",
      location: "Penang",
      rating: 5,
      comment: "Love the fit and the beautiful lace details. Fast shipping and excellent customer service!",
      image: "/placeholder.svg?height=60&width=60&text=M",
    },
    {
      name: "Amanda K.",
      location: "Johor Bahru",
      rating: 5,
      comment: "Finally found lingerie that's both beautiful and comfortable. The rose gold collection is stunning!",
      image: "/placeholder.svg?height=60&width=60&text=A",
    },
  ]

  return (
    <section className="py-16 bg-gradient-to-br from-stone-50 to-rose-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-stone-800 mb-4">What Our Customers Say</h2>
          <p className="text-lg text-stone-600">Real reviews from real customers</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3 mb-4">
                  <Image
                    src={testimonial.image || "/placeholder.svg"}
                    alt={testimonial.name}
                    width={60}
                    height={60}
                    className="rounded-full"
                  />
                  <div>
                    <h4 className="font-semibold text-stone-800">{testimonial.name}</h4>
                    <p className="text-sm text-stone-600">{testimonial.location}</p>
                  </div>
                </div>

                <div className="flex mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>

                <p className="text-stone-600 italic">"{testimonial.comment}"</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
