import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Heart, Users, Star, Briefcase } from "lucide-react"

export default function CareersPage() {
  const positions = [
    {
      title: "Customer Service Representative",
      type: "Full-time",
      location: "Kuala Lumpur",
      description:
        "Join our customer service team to help customers find their perfect fit and provide exceptional support.",
    },
    {
      title: "Social Media Manager",
      type: "Part-time",
      location: "Remote",
      description: "Manage our social media presence and create engaging content for our luxury lingerie brand.",
    },
    {
      title: "Sales Associate",
      type: "Full-time",
      location: "Kuala Lumpur",
      description: "Work in our boutique providing personalized styling advice and exceptional customer experiences.",
    },
  ]

  const benefits = [
    {
      icon: Heart,
      title: "Employee Discount",
      description: "40% off all Josie Luxe products",
    },
    {
      icon: Users,
      title: "Team Culture",
      description: "Join a supportive, female-empowering team",
    },
    {
      icon: Star,
      title: "Growth Opportunities",
      description: "Career development and training programs",
    },
    {
      icon: Briefcase,
      title: "Flexible Hours",
      description: "Work-life balance is important to us",
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-stone-800 mb-8 font-playfair text-center">Join Our Team</h1>

          <div className="text-center mb-12">
            <p className="text-lg text-stone-600 max-w-2xl mx-auto">
              Be part of a growing luxury lingerie brand that empowers women and celebrates confidence. We're looking
              for passionate individuals who share our values.
            </p>
          </div>

          {/* Benefits */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center">
                <CardContent className="pt-6">
                  <div className="w-12 h-12 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <benefit.icon className="w-6 h-6 text-rose-500" />
                  </div>
                  <h3 className="font-semibold text-stone-800 mb-2">{benefit.title}</h3>
                  <p className="text-sm text-stone-600">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Open Positions */}
          <div className="space-y-6 mb-12">
            <h2 className="text-2xl font-bold text-stone-800 text-center">Open Positions</h2>

            {positions.map((position, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl text-stone-800">{position.title}</CardTitle>
                      <div className="flex gap-4 text-sm text-stone-600 mt-2">
                        <span>{position.type}</span>
                        <span>📍 {position.location}</span>
                      </div>
                    </div>
                    <Button className="bg-rose-500 hover:bg-rose-600">Apply Now</Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-stone-600">{position.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Application Process */}
          <Card className="bg-rose-50">
            <CardHeader>
              <CardTitle className="text-center">How to Apply</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-stone-600 mb-6">
                Ready to join the Josie Luxe family? Send us your resume and a brief cover letter explaining why you'd
                be a great fit for our team.
              </p>
              <div className="space-y-2 text-stone-600">
                <p>📧 careers@josieluxe.com</p>
                <p>📱 +60 12-345 6789</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  )
}
