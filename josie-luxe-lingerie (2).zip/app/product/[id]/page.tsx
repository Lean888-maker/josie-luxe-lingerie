"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Heart, ShoppingBag, Star, Minus, Plus, Truck, RotateCcw, Shield } from "lucide-react"
import Image from "next/image"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default function ProductDetailPage() {
  const [selectedSize, setSelectedSize] = useState("")
  const [selectedColor, setSelectedColor] = useState(0)
  const [quantity, setQuantity] = useState(1)

  const product = {
    id: 1,
    name: "Silk Dreams Luxury Bra Set",
    price: 299.99,
    originalPrice: 399.99,
    rating: 4.8,
    reviews: 124,
    images: [
      "/placeholder.svg?height=600&width=500",
      "/placeholder.svg?height=600&width=500",
      "/placeholder.svg?height=600&width=500",
      "/placeholder.svg?height=600&width=500",
    ],
    colors: [
      { name: "Blush Pink", value: "#FFB6C1" },
      { name: "Lavender", value: "#E6E6FA" },
      { name: "Classic Black", value: "#000000" },
    ],
    sizes: ["32A", "32B", "32C", "34A", "34B", "34C", "36A", "36B", "36C"],
    description:
      "Indulge in luxury with our Silk Dreams collection. This exquisite bra set combines premium silk with delicate lace detailing for the ultimate in comfort and elegance. Perfect for special occasions or when you want to feel your most confident.",
    features: [
      "Premium silk construction",
      "Delicate lace detailing",
      "Underwire support",
      "Adjustable straps",
      "Hook and eye closure",
      "Matching panties included",
    ],
    careInstructions: "Hand wash cold, lay flat to dry. Do not bleach or iron directly on lace.",
    isNew: true,
  }

  return (
    <div className="min-h-screen relative">
      <div className="absolute inset-0 bg-gradient-to-br from-white via-pink-50/10 to-purple-50/5" />
      <div className="relative z-10">
        <Header />

        <div className="container mx-auto px-4 py-8">
          {/* Product Images */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Product Images */}
            <div className="space-y-4">
              <div className="aspect-square overflow-hidden rounded-lg bg-gray-100">
                <Image
                  src={product.images[selectedColor] || "/placeholder.svg"}
                  alt={product.name}
                  width={500}
                  height={600}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="grid grid-cols-4 gap-4">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedColor(index)}
                    className={`aspect-square overflow-hidden rounded-lg border-2 ${
                      selectedColor === index ? "border-pink-500" : "border-gray-200"
                    }`}
                  >
                    <Image
                      src={image || "/placeholder.svg"}
                      alt={`${product.name} ${index + 1}`}
                      width={120}
                      height={120}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Details */}
            <div className="space-y-6">
              <div>
                {product.isNew && <Badge className="bg-green-500 hover:bg-green-600 mb-2">New Arrival</Badge>}
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex items-center gap-1">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-5 h-5 ${
                            i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600">
                      {product.rating} ({product.reviews} reviews)
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-3xl font-bold text-gray-900">RM{product.price}</span>
                  {product.originalPrice && (
                    <span className="text-xl text-gray-500 line-through">RM{product.originalPrice}</span>
                  )}
                  {product.originalPrice && (
                    <Badge variant="destructive">Save RM{(product.originalPrice - product.price).toFixed(2)}</Badge>
                  )}
                </div>
              </div>

              <p className="text-gray-600 leading-relaxed">{product.description}</p>

              {/* Color Selection */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Color: {product.colors[selectedColor].name}</h3>
                <div className="flex gap-3">
                  {product.colors.map((color, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedColor(index)}
                      className={`w-12 h-12 rounded-full border-4 ${
                        selectedColor === index ? "border-pink-500" : "border-gray-300"
                      }`}
                      style={{ backgroundColor: color.value }}
                      title={color.name}
                    />
                  ))}
                </div>
              </div>

              {/* Size Selection */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Size</h3>
                <Select value={selectedSize} onValueChange={setSelectedSize}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select your size" />
                  </SelectTrigger>
                  <SelectContent>
                    {product.sizes.map((size) => (
                      <SelectItem key={size} value={size}>
                        {size}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="link" className="p-0 h-auto text-pink-500 mt-2">
                  Size Guide
                </Button>
              </div>

              {/* Quantity */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Quantity</h3>
                <div className="flex items-center gap-3">
                  <Button variant="outline" size="icon" onClick={() => setQuantity(Math.max(1, quantity - 1))}>
                    <Minus className="w-4 h-4" />
                  </Button>
                  <span className="text-lg font-medium w-12 text-center">{quantity}</span>
                  <Button variant="outline" size="icon" onClick={() => setQuantity(quantity + 1)}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Add to Cart */}
              <div className="space-y-3">
                <Button size="lg" className="w-full bg-pink-500 hover:bg-pink-600 text-white" disabled={!selectedSize}>
                  <ShoppingBag className="w-5 h-5 mr-2" />
                  Add to Cart - RM{(product.price * quantity).toFixed(2)}
                </Button>
                <Button size="lg" variant="outline" className="w-full bg-transparent">
                  <Heart className="w-5 h-5 mr-2" />
                  Add to Wishlist
                </Button>
              </div>

              {/* Features */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-6 border-t">
                <div className="flex items-center gap-2">
                  <Truck className="w-5 h-5 text-pink-500" />
                  <span className="text-sm">Free shipping over RM75</span>
                </div>
                <div className="flex items-center gap-2">
                  <RotateCcw className="w-5 h-5 text-pink-500" />
                  <span className="text-sm">30-day returns</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-pink-500" />
                  <span className="text-sm">Secure checkout</span>
                </div>
              </div>
            </div>
          </div>

          {/* Product Details Tabs */}
          <div className="mt-16">
            <Tabs defaultValue="details" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="care">Care Instructions</TabsTrigger>
                <TabsTrigger value="reviews">Reviews ({product.reviews})</TabsTrigger>
              </TabsList>
              <TabsContent value="details" className="mt-6">
                <div className="prose max-w-none">
                  <h3 className="text-xl font-semibold mb-4">Product Features</h3>
                  <ul className="space-y-2">
                    {product.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-pink-500 rounded-full" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </TabsContent>
              <TabsContent value="care" className="mt-6">
                <div className="prose max-w-none">
                  <h3 className="text-xl font-semibold mb-4">Care Instructions</h3>
                  <p className="text-gray-600">{product.careInstructions}</p>
                </div>
              </TabsContent>
              <TabsContent value="reviews" className="mt-6">
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-semibold">Customer Reviews</h3>
                    <Button variant="outline">Write a Review</Button>
                  </div>
                  <div className="text-center py-12 text-gray-500">Reviews coming soon...</div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        <Footer />
      </div>
    </div>
  )
}
