import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Heart, Star, Award, Users, Truck, Shield } from "lucide-react"
import Image from "next/image"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default function AboutPage() {
  const values = [
    {
      icon: Heart,
      title: "Comfort First",
      description: "Every piece is designed with your comfort and confidence in mind",
    },
    {
      icon: Star,
      title: "Premium Quality",
      description: "We use only the finest materials and craftsmanship",
    },
    {
      icon: Award,
      title: "Elegant Design",
      description: "Timeless designs that make you feel beautiful every day",
    },
    {
      icon: Users,
      title: "Customer Focused",
      description: "Your satisfaction is our top priority",
    },
  ]

  const stats = [
    { number: "10,000+", label: "Happy Customers" },
    { number: "500+", label: "Products Sold" },
    { number: "4.9/5", label: "Customer Rating" },
    { number: "2+", label: "Years of Excellence" },
  ]

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-rose-50 via-amber-50 to-stone-50 py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-stone-800 mb-6 font-playfair">
              About Josie{" "}
              <span className="text-rose-500" style={{ fontStyle: "italic" }}>
                Luxe
              </span>
            </h1>
            <p className="text-xl text-stone-600 mb-8 leading-relaxed">
              Empowering women through luxury intimate wear that celebrates confidence, comfort, and elegance.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-stone-800 mb-6">Our Story</h2>
              <div className="space-y-4 text-stone-600 leading-relaxed">
                <p>
                  Founded with a passion for creating beautiful, comfortable intimate wear, Josie Luxe began as a dream
                  to provide Malaysian women with luxury lingerie that doesn't compromise on quality or style.
                </p>
                <p>
                  We believe that every woman deserves to feel confident and beautiful in her own skin. That's why we
                  carefully curate and design pieces that celebrate femininity while providing the comfort and support
                  you need throughout your day.
                </p>
                <p>
                  From our premium silk collections to our everyday comfort essentials, each piece is selected with love
                  and attention to detail, ensuring you receive only the finest quality intimate wear.
                </p>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=400&text=Elegant+Lingerie+Collection"
                alt="Josie Luxe Collection"
                width={400}
                height={500}
                className="rounded-2xl shadow-xl"
              />
              <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-rose-200 rounded-full opacity-60"></div>
              <div className="absolute -top-6 -right-6 w-24 h-24 bg-amber-200 rounded-full opacity-60"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-16 bg-gradient-to-br from-stone-50 to-rose-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-stone-800 mb-4">Our Values</h2>
            <p className="text-lg text-stone-600 max-w-2xl mx-auto">
              The principles that guide everything we do at Josie Luxe
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow duration-300">
                <CardContent className="pt-8 pb-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-rose-100 to-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-8 h-8 text-rose-500" />
                  </div>
                  <h3 className="text-xl font-semibold text-stone-800 mb-3">{value.title}</h3>
                  <p className="text-stone-600">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-rose-500 mb-2">{stat.number}</div>
                <div className="text-stone-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-gradient-to-br from-rose-50 to-amber-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-stone-800 mb-4">Why Choose Josie Luxe?</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Truck className="w-10 h-10 text-rose-500" />
              </div>
              <h3 className="text-xl font-semibold text-stone-800 mb-3">Fast & Free Shipping</h3>
              <p className="text-stone-600">Free shipping on orders above RM129. Fast delivery across Malaysia.</p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Shield className="w-10 h-10 text-rose-500" />
              </div>
              <h3 className="text-xl font-semibold text-stone-800 mb-3">Quality Guarantee</h3>
              <p className="text-stone-600">30-day return policy. We stand behind the quality of our products.</p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Heart className="w-10 h-10 text-rose-500" />
              </div>
              <h3 className="text-xl font-semibold text-stone-800 mb-3">Customer Care</h3>
              <p className="text-stone-600">Dedicated customer support to help you find the perfect fit.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-stone-800 mb-4">Ready to Experience Luxury?</h2>
          <p className="text-lg text-stone-600 mb-8 max-w-2xl mx-auto">
            Discover our collection of premium intimate wear designed to make you feel confident and beautiful.
          </p>
          <Button
            size="lg"
            className="bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white px-8 py-3"
          >
            Shop Now
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  )
}
