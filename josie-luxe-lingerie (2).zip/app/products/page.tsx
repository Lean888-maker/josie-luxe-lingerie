"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Heart, ShoppingBag, Star, Filter } from "lucide-react"
import Image from "next/image"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default function ProductsPage() {
  const [selectedFilters, setSelectedFilters] = useState({
    category: [],
    size: [],
    color: [],
    price: [],
  })

  const products = [
    {
      id: 1,
      name: "Silk Dreams Bra Set",
      price: 89.99,
      originalPrice: 119.99 * 3.0,
      image: "/placeholder.svg?height=400&width=300",
      rating: 4.8,
      reviews: 124,
      colors: ["#FFB6C1", "#E6E6FA", "#000000"],
      sizes: ["32B", "34B", "36B"],
      category: "Sets",
      isNew: true,
    },
    {
      id: 2,
      name: "Lace Elegance Bra",
      price: 45.99 * 3.0,
      originalPrice: 65.99 * 3.0,
      image: "/placeholder.svg?height=400&width=300",
      rating: 4.9,
      reviews: 89,
      colors: ["#FFFFFF", "#FFB6C1", "#8B4513"],
      sizes: ["32A", "34A", "36A"],
      category: "Bras",
      isSale: true,
    },
    {
      id: 3,
      name: "Comfort Plus Wireless",
      price: 35.99 * 3.0,
      image: "/placeholder.svg?height=400&width=300",
      rating: 4.7,
      reviews: 156,
      colors: ["#000000", "#FFFFFF", "#D2691E"],
      sizes: ["32C", "34C", "36C"],
      category: "Bras",
    },
    {
      id: 4,
      name: "Romantic Rose Panties",
      price: 25.99 * 3.0,
      originalPrice: 35.99 * 3.0,
      image: "/placeholder.svg?height=400&width=300",
      rating: 4.8,
      reviews: 203,
      colors: ["#FF69B4", "#FFFFFF", "#8B0000"],
      sizes: ["S", "M", "L"],
      category: "Panties",
      isNew: true,
    },
    {
      id: 5,
      name: "Midnight Satin Set",
      price: 125.99 * 3.0,
      image: "/placeholder.svg?height=400&width=300",
      rating: 4.9,
      reviews: 78,
      colors: ["#000000", "#8B0000"],
      sizes: ["32B", "34B", "36B"],
      category: "Sets",
    },
    {
      id: 6,
      name: "Cotton Comfort Bra",
      price: 29.99 * 3.0,
      originalPrice: 39.99 * 3.0,
      image: "/placeholder.svg?height=400&width=300",
      rating: 4.6,
      reviews: 234,
      colors: ["#FFFFFF", "#000000", "#D2691E"],
      sizes: ["32A", "34A", "36A"],
      category: "Bras",
      isSale: true,
    },
  ]

  return (
    <div className="min-h-screen relative">
      <div className="absolute inset-0 bg-gradient-to-br from-gray-50 via-pink-50/20 to-purple-50/10" />
      <div className="relative z-10">
        <Header />

        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Filters Sidebar */}
            <div className="lg:w-1/4">
              <div className="bg-white rounded-lg p-6 sticky top-24 shadow-sm">
                <div className="flex items-center gap-2 mb-6">
                  <Filter className="w-5 h-5" />
                  <h2 className="text-lg font-semibold">Filters</h2>
                </div>

                {/* Category Filter */}
                <div className="mb-6">
                  <h3 className="font-medium mb-3">Category</h3>
                  <div className="space-y-2">
                    {["Bras", "Panties", "Sets", "Sleepwear"].map((category) => (
                      <div key={category} className="flex items-center space-x-2">
                        <Checkbox id={category} />
                        <label htmlFor={category} className="text-sm">
                          {category}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Size Filter */}
                <div className="mb-6">
                  <h3 className="font-medium mb-3">Size</h3>
                  <div className="space-y-2">
                    {["32A", "32B", "32C", "34A", "34B", "34C", "S", "M", "L"].map((size) => (
                      <div key={size} className="flex items-center space-x-2">
                        <Checkbox id={size} />
                        <label htmlFor={size} className="text-sm">
                          {size}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Price Filter */}
                <div className="mb-6">
                  <h3 className="font-medium mb-3">Price Range</h3>
                  <div className="space-y-2">
                    {["Under RM100", "RM100 - RM200", "RM200 - RM300", "RM300 - RM400", "Over RM400"].map((range) => (
                      <div key={range} className="flex items-center space-x-2">
                        <Checkbox id={range} />
                        <label htmlFor={range} className="text-sm">
                          {range}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                <Button className="w-full bg-pink-500 hover:bg-pink-600">Apply Filters</Button>
              </div>
            </div>

            {/* Products Grid */}
            <div className="lg:w-3/4">
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">All Products ({products.length})</h1>
                <Select>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="featured">Featured</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product) => (
                  <Card key={product.id} className="group hover:shadow-lg transition-shadow duration-300 bg-white">
                    <CardContent className="p-0">
                      <div className="relative overflow-hidden">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          width={300}
                          height={400}
                          className="w-full h-80 object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute top-3 left-3 flex flex-col gap-2">
                          {product.isNew && <Badge className="bg-green-500 hover:bg-green-600">New</Badge>}
                          {product.isSale && <Badge className="bg-red-500 hover:bg-red-600">Sale</Badge>}
                        </div>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="absolute top-3 right-3 bg-white/80 hover:bg-white"
                        >
                          <Heart className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="p-4">
                        <h3 className="font-semibold text-gray-800 mb-2 line-clamp-2">{product.name}</h3>

                        <div className="flex items-center gap-1 mb-2">
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-4 h-4 ${
                                  i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-sm text-gray-600">({product.reviews})</span>
                        </div>

                        <div className="flex items-center gap-2 mb-3">
                          {product.colors.map((color, index) => (
                            <div
                              key={index}
                              className="w-4 h-4 rounded-full border border-gray-300"
                              style={{ backgroundColor: color }}
                            />
                          ))}
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="text-lg font-bold text-gray-800">RM{product.price.toFixed(2)}</span>
                            {product.originalPrice && (
                              <span className="text-sm text-gray-500 line-through">
                                RM{product.originalPrice.toFixed(2)}
                              </span>
                            )}
                          </div>
                          <Button size="sm" className="bg-pink-500 hover:bg-pink-600">
                            <ShoppingBag className="w-4 h-4 mr-1" />
                            Add
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </div>
  )
}
