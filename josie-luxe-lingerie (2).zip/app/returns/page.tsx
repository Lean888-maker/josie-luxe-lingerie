import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RotateCcw, Package, Clock, CheckCircle } from "lucide-react"

export default function ReturnsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-stone-800 mb-8 font-playfair text-center">Returns & Exchanges</h1>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-rose-500" />
              </div>
              <h3 className="font-semibold text-stone-800 mb-2">30 Days</h3>
              <p className="text-sm text-stone-600">Return window</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package className="w-8 h-8 text-amber-500" />
              </div>
              <h3 className="font-semibold text-stone-800 mb-2">Original Packaging</h3>
              <p className="text-sm text-stone-600">With tags attached</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="font-semibold text-stone-800 mb-2">Unworn</h3>
              <p className="text-sm text-stone-600">Hygienic condition</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <RotateCcw className="w-8 h-8 text-blue-500" />
              </div>
              <h3 className="font-semibold text-stone-800 mb-2">Free Returns</h3>
              <p className="text-sm text-stone-600">No return shipping fee</p>
            </div>
          </div>

          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Return Policy</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-stone-600">
                  We want you to love your Josie Luxe purchase. If you're not completely satisfied, you can return items
                  within 30 days of delivery for a full refund or exchange.
                </p>
                <ul className="list-disc pl-6 text-stone-600 space-y-2">
                  <li>Items must be in original condition with tags attached</li>
                  <li>Intimate apparel must be unworn for hygiene reasons</li>
                  <li>Original packaging and receipt required</li>
                  <li>Sale items are final sale (unless defective)</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>How to Return</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="w-8 h-8 bg-rose-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                      1
                    </div>
                    <div>
                      <h4 className="font-semibold text-stone-800">Contact Us</h4>
                      <p className="text-stone-600">Email support@josieluxe.com or call +60 12-345 6789</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 bg-rose-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                      2
                    </div>
                    <div>
                      <h4 className="font-semibold text-stone-800">Get Return Label</h4>
                      <p className="text-stone-600">We'll email you a prepaid return shipping label</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 bg-rose-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                      3
                    </div>
                    <div>
                      <h4 className="font-semibold text-stone-800">Pack & Ship</h4>
                      <p className="text-stone-600">Pack items securely and drop off at any Pos Malaysia location</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 bg-rose-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                      4
                    </div>
                    <div>
                      <h4 className="font-semibold text-stone-800">Get Refund</h4>
                      <p className="text-stone-600">
                        Refund processed within 5-7 business days after we receive your return
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="text-center bg-rose-50 rounded-lg p-8">
              <h2 className="text-2xl font-semibold text-stone-800 mb-4">Need Help with Your Return?</h2>
              <p className="text-stone-600 mb-6">
                Our customer service team is here to make your return process as smooth as possible.
              </p>
              <Button className="bg-rose-500 hover:bg-rose-600">Contact Support</Button>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
