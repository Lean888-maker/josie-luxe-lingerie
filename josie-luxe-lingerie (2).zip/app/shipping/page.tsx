import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Truck, Clock, MapPin } from "lucide-react"

export default function ShippingPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-stone-800 mb-8 font-playfair">Shipping Information</h1>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="w-8 h-8 text-rose-500" />
              </div>
              <h3 className="text-lg font-semibold text-stone-800 mb-2">Free Shipping</h3>
              <p className="text-stone-600">On orders above RM129</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-amber-500" />
              </div>
              <h3 className="text-lg font-semibold text-stone-800 mb-2">Fast Delivery</h3>
              <p className="text-stone-600">2-5 business days</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-8 h-8 text-stone-500" />
              </div>
              <h3 className="text-lg font-semibold text-stone-800 mb-2">Nationwide</h3>
              <p className="text-stone-600">All states in Malaysia</p>
            </div>
          </div>

          <div className="space-y-8">
            <section>
              <h2 className="text-2xl font-semibold text-stone-800 mb-4">Shipping Rates</h2>
              <div className="bg-stone-50 rounded-lg p-6">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-stone-600">Orders below RM129</span>
                    <span className="font-semibold">RM15</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-600">Orders RM129 and above</span>
                    <span className="font-semibold text-green-600">FREE</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-600">Express delivery (next day)</span>
                    <span className="font-semibold">RM25</span>
                  </div>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-stone-800 mb-4">Delivery Areas</h2>
              <p className="text-stone-600 leading-relaxed mb-4">
                We currently deliver to all states in Malaysia including:
              </p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-stone-600">
                <div>• Kuala Lumpur</div>
                <div>• Selangor</div>
                <div>• Penang</div>
                <div>• Johor</div>
                <div>• Perak</div>
                <div>• Sabah</div>
                <div>• Sarawak</div>
                <div>• Kedah</div>
                <div>• And more...</div>
              </div>
            </section>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
