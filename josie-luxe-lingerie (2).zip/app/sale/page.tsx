import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Heart, ShoppingBag, Star, Clock } from "lucide-react"
import Image from "next/image"

export default function SalePage() {
  const saleProducts = [
    {
      id: 1,
      name: "Silk Dreams Bra Set",
      price: 199.99,
      originalPrice: 299.99,
      image: "/placeholder.svg?height=400&width=300&text=Rose+Gold+Silk+Sale",
      rating: 4.8,
      reviews: 124,
      discount: 33,
    },
    {
      id: 2,
      name: "Lace Elegance Collection",
      price: 149.99,
      originalPrice: 249.99,
      image: "/placeholder.svg?height=400&width=300&text=Ivory+Lace+Sale",
      rating: 4.9,
      reviews: 89,
      discount: 40,
    },
    {
      id: 3,
      name: "Romantic Rose Set",
      price: 179.99,
      originalPrice: 319.99,
      image: "/placeholder.svg?height=400&width=300&text=Rose+Set+Sale",
      rating: 4.8,
      reviews: 203,
      discount: 44,
    },
    {
      id: 4,
      name: "Champagne Dreams",
      price: 189.99,
      originalPrice: 319.99,
      image: "/placeholder.svg?height=400&width=300&text=Champagne+Sale",
      rating: 4.8,
      reviews: 143,
      discount: 41,
    },
    {
      id: 5,
      name: "Classic Black Elegance",
      price: 159.99,
      originalPrice: 269.99,
      image: "/placeholder.svg?height=400&width=300&text=Black+Elegance+Sale",
      rating: 4.9,
      reviews: 167,
      discount: 41,
    },
    {
      id: 6,
      name: "Pearl White Luxury",
      price: 229.99,
      originalPrice: 399.99,
      image: "/placeholder.svg?height=400&width=300&text=Pearl+White+Sale",
      rating: 5.0,
      reviews: 76,
      discount: 43,
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Sale Banner */}
      <section className="bg-gradient-to-r from-red-500 to-pink-500 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 font-playfair">SEASONAL SALE</h1>
          <p className="text-xl mb-6">Up to 60% OFF Premium Lingerie</p>
          <div className="flex items-center justify-center gap-2 text-lg">
            <Clock className="w-5 h-5" />
            <span>Limited Time Only - Ends Soon!</span>
          </div>
        </div>
      </section>

      {/* Sale Products */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-stone-800 mb-4">Sale Items</h2>
            <p className="text-lg text-stone-600">Luxury lingerie at unbeatable prices</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {saleProducts.map((product) => (
              <Card key={product.id} className="group hover:shadow-xl transition-all duration-300 bg-white">
                <CardContent className="p-0">
                  <div className="relative overflow-hidden">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={300}
                      height={400}
                      className="w-full h-80 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 left-3">
                      <Badge className="bg-red-500 hover:bg-red-600 text-white text-lg px-3 py-1">
                        -{product.discount}%
                      </Badge>
                    </div>
                    <Button size="icon" variant="ghost" className="absolute top-3 right-3 bg-white/90 hover:bg-white">
                      <Heart className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="p-4">
                    <h3 className="font-semibold text-stone-800 mb-2 line-clamp-2">{product.name}</h3>

                    <div className="flex items-center gap-1 mb-2">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-stone-600">({product.reviews})</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xl font-bold text-red-600">RM{product.price}</span>
                        <span className="text-sm text-stone-500 line-through">RM{product.originalPrice}</span>
                      </div>
                      <Button size="sm" className="bg-red-500 hover:bg-red-600">
                        <ShoppingBag className="w-4 h-4 mr-1" />
                        Add
                      </Button>
                    </div>

                    <div className="mt-2">
                      <span className="text-sm text-green-600 font-semibold">
                        Save RM{(product.originalPrice - product.price).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Sale Terms */}
      <section className="py-8 bg-stone-50">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h3 className="text-xl font-semibold text-stone-800 mb-4">Sale Terms & Conditions</h3>
            <div className="text-sm text-stone-600 space-y-2">
              <p>• Sale prices valid while stocks last</p>
              <p>• Cannot be combined with other offers</p>
              <p>• Sale items are final sale unless defective</p>
              <p>• Standard return policy applies to non-sale items</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
