import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function FAQPage() {
  const faqs = [
    {
      question: "What is your return policy?",
      answer:
        "We offer a 30-day return policy for all items in original condition with tags attached. For hygiene reasons, intimate apparel must be unworn.",
    },
    {
      question: "How do I find my correct size?",
      answer:
        "Please refer to our detailed size guide page. We recommend measuring yourself and comparing with our size chart. If you're unsure, our customer service team is happy to help.",
    },
    {
      question: "Do you offer free shipping?",
      answer:
        "Yes! We offer free shipping on all orders above RM129 within Malaysia. Orders below this amount have a flat shipping rate of RM15.",
    },
    {
      question: "How long does delivery take?",
      answer:
        "Standard delivery takes 2-5 business days within Malaysia. Express next-day delivery is available for RM25 additional charge.",
    },
    {
      question: "What payment methods do you accept?",
      answer:
        "We accept bank transfers, online banking, and cash on delivery (COD). All payments are processed securely.",
    },
    {
      question: "Can I exchange items for a different size?",
      answer:
        "Yes, exchanges are possible within 30 days of purchase. Items must be in original condition with tags attached.",
    },
    {
      question: "Do you have a physical store?",
      answer:
        "Yes, we have a boutique located at 123 Jalan Bukit Bintang, Kuala Lumpur. You're welcome to visit us during business hours.",
    },
    {
      question: "How do I care for my lingerie?",
      answer:
        "We recommend hand washing in cold water with gentle detergent. Lay flat to dry and avoid direct sunlight. Do not bleach or iron directly on lace.",
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-stone-800 mb-8 font-playfair text-center">
            Frequently Asked Questions
          </h1>

          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border border-stone-200 rounded-lg px-6">
                <AccordionTrigger className="text-left font-semibold text-stone-800 hover:text-rose-600">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-stone-600 leading-relaxed">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="mt-12 text-center bg-rose-50 rounded-lg p-8">
            <h2 className="text-2xl font-semibold text-stone-800 mb-4">Still have questions?</h2>
            <p className="text-stone-600 mb-6">
              Our customer service team is here to help you find the perfect fit and answer any questions you may have.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/contact"
                className="bg-rose-500 hover:bg-rose-600 text-white px-6 py-3 rounded-full font-semibold transition-colors"
              >
                Contact Us
              </a>
              <a
                href="tel:+60123456789"
                className="border border-rose-500 text-rose-600 hover:bg-rose-50 px-6 py-3 rounded-full font-semibold transition-colors"
              >
                Call +60 12-345 6789
              </a>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
